package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;

import view.LoginView;
import view.ProductView;
import dao.UserDao;
import main.Main;
import model.User;

public class LoginController {
	
	private UserDao user_dao;
	private LoginView login_view;
	private ProductView pr_view;

	public LoginController(UserDao u_dao, LoginView dialog, ProductView p_view) {
		user_dao = u_dao;
		login_view = dialog;
		pr_view = p_view;
		
		//Add Submit Listener
		dialog.addSubmitListener(new Submit());
	}
	
	class Submit implements ActionListener {
        public void actionPerformed(ActionEvent e) {
        	String username = login_view.getUsername().getText();
        	String password = login_view.getPassword().getText();
        	checkLogin(username, password);
        }
	}

	private void checkLogin(String username, String password) {
		User user = user_dao.getUser(username);
		if (user.getPassword() == password){
			Main.name = user.getName();
			Main.rights = user.getProfile().getRightLabels();
			pr_view.logout();
			
		}
			
	}

}
