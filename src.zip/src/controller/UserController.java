package controller;

public interface UserController extends Controller {

}
