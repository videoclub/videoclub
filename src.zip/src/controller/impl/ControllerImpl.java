package controller.impl;

import controller.Controller;
import controller.RightsController;


public abstract class ControllerImpl extends RightsController implements Controller{
	

}
