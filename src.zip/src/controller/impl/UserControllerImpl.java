package controller.impl;

import java.util.ArrayList;

import model.User;

import view.LoginView;
import view.ManageProductView;
import view.ProductView;

import controller.UserController;
import dao.UserDao;

public class UserControllerImpl extends ControllerImpl implements UserController {

	@Override
	public void getAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Object> getOne(String title) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void set() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(ArrayList<Object> item) {
		// TODO Auto-generated method stub
		
	}
}
