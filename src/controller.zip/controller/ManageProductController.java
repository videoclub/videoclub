package controller;

public interface ManageProductController extends Controller{

}
