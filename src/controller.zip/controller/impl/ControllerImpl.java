package controller.impl;

import view.ProductView;
import controller.Controller;
import dao.impl.DaoImpl;

public abstract class ControllerImpl implements Controller{
	
	private DaoImpl dao;
	public ProductView pr_view;

	public void dbConnect(){
		dao.openConnection();
	}
	
	public void dbDisconnect(){
		dao.closeConnection();
	}

}
